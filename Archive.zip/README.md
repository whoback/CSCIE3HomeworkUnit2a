CSCIE3HomeworkUnit2a
====================
